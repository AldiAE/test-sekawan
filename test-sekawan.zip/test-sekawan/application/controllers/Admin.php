<?php
defined('BASEPATH') OR exit('No direct script access allowed');
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Admin extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        is_login();

        $this->load->model('m_sekawan');
    }

	public function index()
	{
        $data['graph'] = $this->m_sekawan->dashboard('orders')->result();
		$this->load->view('template/header');
		$this->load->view('template/navbar');
		$this->load->view('admin/dashboard',$data);
		$this->load->view('template/footer');
	}

    public function order()
    {
        $data['orders'] = $this->db->get('orders')->result_array();        
        $data['kendaraan'] = $this->db->get('kendaraan')->result_array();        
        $data['users'] = $this->db->get('user')->result_array();        
        
        $this->load->view('template/header');
		$this->load->view('template/navbar');
		$this->load->view('admin/order',$data);
		$this->load->view('template/footer');
    }

    public function tambah($id = null)
    {

        $this->form_validation->set_rules('nama_pemesan','nama_pemesan','required');
        $this->form_validation->set_rules('nama_driver','nama_driver','required');
        $this->form_validation->set_rules('tanggal_pesan','tanggal_pesan','required');
        $this->form_validation->set_rules('tanggal_kembali','tanggal_kembali','required');
        $this->form_validation->set_rules('nama_kendaraan','nama_kendaraan','required');
        if ($this->form_validation->run() == FALSE)
        {
            redirect(base_url('admin/order'));
            
        }
        else
        {
            $data = array(
                'nama_pemesan' => htmlspecialchars($this->input->post('nama_pemesan',true)),
                'nama_driver' => htmlspecialchars($this->input->post('nama_driver',true)),
                'nama_pemesan' => htmlspecialchars($this->input->post('nama_pemesan',true)),
                'tanggal_pesan' => $this->input->post('tanggal_pesan',true),
                'tanggal_kembali' => $this->input->post('tanggal_kembali',true),
                'id_kendaraan' => $this->input->post('nama_kendaraan',true)
            );
            if($id != null) {
                $this->db->update('orders',$data,array('id_order' => $id));
                set_log("update","update orders", $id);
                redirect(base_url('admin/order'));
            }else{
                $this->db->insert('orders',$data);
                set_log("tambah","tambah orders", '+');
                redirect(base_url('admin/order'));
            }
        }
        
    }

    public function set_persetujuan()
    {
        
        $this->db->delete('persetujuan',array('id_order' => $this->input->post('id_order', true)));
        if(!empty($this->input->post('persetujuan'))){
            $persetujuan = $this->input->post('persetujuan', true);
            foreach($persetujuan as $key => $p) {
                $data = array(
                    'id_user' => $p,
                    'id_order' => $this->input->post('id_order', true),
                    'level' => $key+1,
                    'status' => 0
                );
                $this->db->insert('persetujuan',$data); 
                
            }
            set_log("tambah","tambah persetujuan", $this->input->post('id_order', true));
            redirect(base_url('admin/order'));

        }else{
            redirect(base_url('admin/order'));
        }
        
    }

    public function get_by_id()
    {
        if(!empty($this->input->post('id_order', true))) {
            $data = $this->db->get_where('orders',array('id_order' => $this->input->post('id_order', true)))->result_array();
            if($data) {
                echo json_encode($data[0]);
            }
        }
    }

    public function hapus_by_id()
    {
        if(!empty($this->input->post('id_order', true))) {
            $this->db->delete('orders',array('id_order' => $this->input->post('id_order', true)));
            set_log("hapus","hapus orders", $this->input->post('id_order', true));
        }
    }

    public function kendaraan()
    {
        $data['kendaraan'] = $this->db->get('kendaraan')->result_array();
        $this->load->view('template/header');
		$this->load->view('template/navbar');
		$this->load->view('admin/kendaraan',$data);
		$this->load->view('template/footer');
    }

    public function tambah_kendaraan($id = null) 
    {
        
        $this->form_validation->set_rules('nama_kendaraan','nama_kendaraan','required');
        $this->form_validation->set_rules('konsumsi_bbm','konsumsi_bbm','required');
        $this->form_validation->set_rules('jadwal_service','jadwal_service','required');
        if ($this->form_validation->run() == FALSE)
        {
            redirect(base_url('admin/kendaraan'));
            
        }
        else
        {
            $data = array(
                'nama_kendaraan' => htmlspecialchars($this->input->post('nama_kendaraan',true)),
                'konsumsi_bbm' => htmlspecialchars($this->input->post('konsumsi_bbm',true)),
                'jadwal_service' => htmlspecialchars($this->input->post('jadwal_service',true))
            );
            if($id != null) {
                $this->db->update('kendaraan',$data,array('id_kendaraan' => $id));
                set_log("update","update kendaraan", $id);
                redirect(base_url('admin/kendaraan'));
            }else{
                $this->db->insert('kendaraan',$data);
                set_log("tambah","tambah kendaraan", '+');
                redirect(base_url('admin/kendaraan'));
            }
        }
        
    }

    public function get_kendaraan_by_id()
    {
        if(!empty($this->input->post('id_kend', true))) {
            $data = $this->db->get_where('kendaraan',array('id_kendaraan' => $this->input->post('id_kend', true)))->result_array();
            if($data) {
                echo json_encode($data[0]);
            }
        }
    }

    public function user()
    {
        $data['user'] = $this->db->get('user')->result_array();
        $this->load->view('template/header');
		$this->load->view('template/navbar');
		$this->load->view('admin/user',$data);
		$this->load->view('template/footer');
    }

    public function tambah_user($id = null) 
    {
        
        $this->form_validation->set_rules('nama_lengkap','nama_lengkap','required');
        $this->form_validation->set_rules('username','username','required');
        $this->form_validation->set_rules('role','role','required');
        if ($this->form_validation->run() == FALSE)
        {
            redirect(base_url('admin/user'));
            
        }
        else
        {
            if($id != null) {
                if($this->input->post('password',true) != null) {
                    $data = array(
                        'nama_lengkap' => htmlspecialchars($this->input->post('nama_lengkap',true)),
                        'username' => htmlspecialchars($this->input->post('username',true)),
                        'password' => md5($this->input->post('password',true)),
                        'role' => htmlspecialchars($this->input->post('role',true))
                    );
                }else{
                    $data = array(
                        'nama_lengkap' => htmlspecialchars($this->input->post('nama_lengkap',true)),
                        'username' => htmlspecialchars($this->input->post('username',true)),
                        'role' => htmlspecialchars($this->input->post('role',true))
                    );

                }
                $this->db->update('user',$data,array('id_user' => $id));
                set_log("update","update user", $id);
                redirect(base_url('admin/user'));
            }else{
                $this->form_validation->set_rules('passsword','password','required');
                $data = array(
                    'nama_lengkap' => htmlspecialchars($this->input->post('nama_lengkap',true)),
                    'username' => htmlspecialchars($this->input->post('username',true)),
                    'password' => md5($this->input->post('password',true)),
                    'role' => htmlspecialchars($this->input->post('role',true))
                );
                $this->db->insert('user',$data);
                set_log("tambah","tambah user", '+');
                redirect(base_url('admin/user'));
            }
        }
        
    }

    public function get_user_by_id()
    {
        if(!empty($this->input->post('id_user', true))) {
            $data = $this->db->get_where('user',array('id_user' => $this->input->post('id_user', true)))->result_array();
            if($data) {
                echo json_encode($data[0]);
            }
        }
    }

    public function laporan()
	{
		if(!empty($this->input->post('tanggal_awal', true)) && $this->input->post('tanggal_akhir', true) != ''){

            $spreadsheet = new Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();
            $style_col = [
            'font' => ['bold' => true],
            'alignment' => [
                'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
                'vertical' => \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER
            ],
            'borders' => [
                'top' => ['borderStyle'  => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN], 
                'right' => ['borderStyle'  => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN],
                'bottom' => ['borderStyle'  => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN], 
                'left' => ['borderStyle'  => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN]
            ]
            ];
    
            $style_row = [
            'alignment' => [
                'vertical' => \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER
            ],
            'borders' => [
                'top' => ['borderStyle'  => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN],
                'right' => ['borderStyle'  => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN], 
                'bottom' => ['borderStyle'  => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN],
                'left' => ['borderStyle'  => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN] 
            ]
            ];
            $sheet->setCellValue('A1', "LAPORAN PERIODIK DARI TGL ".$this->input->post('tanggal_awal', true)." - ". $this->input->post('tanggal_akhir', true)); // Set kolom A1 dengan tulisan "DATA SISWA"
            $sheet->mergeCells('A1:F1');
            $sheet->getStyle('A1')->getFont()->setBold(true); 
    
            $sheet->setCellValue('A3', "NO");
            $sheet->setCellValue('B3', "NAMA PEMESAN");
            $sheet->setCellValue('C3', "NAMA DRIVER");
            $sheet->setCellValue('D3', "TANGGAL PESAN");
            $sheet->setCellValue('E3', "TANGGAL KEMBALI");
            $sheet->setCellValue('F3', "NAMA KENDARAAN"); 
    
            $sheet->getStyle('A3')->applyFromArray($style_col);
            $sheet->getStyle('B3')->applyFromArray($style_col);
            $sheet->getStyle('C3')->applyFromArray($style_col);
            $sheet->getStyle('D3')->applyFromArray($style_col);
            $sheet->getStyle('E3')->applyFromArray($style_col);
            $sheet->getStyle('F3')->applyFromArray($style_col);
            // Panggil function view yang ada di SiswaModel untuk menampilkan semua data siswanya
            $data = $this->m_sekawan->cetak($this->input->post('tanggal_awal', true),$this->input->post('tanggal_akhir', true))->result();
    
            $no = 1; // Untuk penomoran tabel, di awal set dengan 1
            $numrow = 4; // Set baris pertama untuk isi tabel adalah baris ke 4
            foreach ($data as $key => $d) {
                
                $sheet->setCellValue('A'.$numrow, $no);
                $sheet->setCellValue('B'.$numrow, $d->nama_pemesan);
                $sheet->setCellValue('C'.$numrow, $d->nama_driver);
                $sheet->setCellValue('D'.$numrow, $d->tanggal_pesan);
                $sheet->setCellValue('E'.$numrow, $d->tanggal_kembali);
                $sheet->setCellValue('F'.$numrow, $d->nama_kendaraan);
                
                // Apply style row yang telah kita buat tadi ke masing-masing baris (isi tabel)
                $sheet->getStyle('A'.$numrow)->applyFromArray($style_row);
                $sheet->getStyle('B'.$numrow)->applyFromArray($style_row);
                $sheet->getStyle('C'.$numrow)->applyFromArray($style_row);
                $sheet->getStyle('D'.$numrow)->applyFromArray($style_row);
                $sheet->getStyle('E'.$numrow)->applyFromArray($style_row);
                $sheet->getStyle('F'.$numrow)->applyFromArray($style_row);
    
                $no++;
                $numrow++;
            }
    
             // Set width kolom
            $sheet->getColumnDimension('A')->setWidth(5); // Set width kolom A
            $sheet->getColumnDimension('B')->setWidth(15); // Set width kolom B
            $sheet->getColumnDimension('C')->setWidth(25); // Set width kolom C
            $sheet->getColumnDimension('D')->setWidth(20); // Set width kolom D
            $sheet->getColumnDimension('E')->setWidth(30); // Set width kolom E
            $sheet->getColumnDimension('F')->setWidth(30); // Set width kolom E
            
            // Set height semua kolom menjadi auto (mengikuti height isi dari kolommnya, jadi otomatis)
            $sheet->getDefaultRowDimension()->setRowHeight(-1);
            // Set orientasi kertas jadi LANDSCAPE
            $sheet->getPageSetup()->setOrientation(\PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::ORIENTATION_LANDSCAPE);
            // Set judul file excel nya
            $sheet->setTitle("Laporan Periodik");
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename="Laporan Periodik.xlsx"'); // Set nama file excel nya
            header('Cache-Control: max-age=0');
            $writer = new Xlsx($spreadsheet);
            $writer->save('php://output');
        }else{
            redirect(base_url('admin/order'));
        }
	}

}
