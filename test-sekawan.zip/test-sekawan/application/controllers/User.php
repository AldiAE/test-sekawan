<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        is_login();

        $this->load->model('m_sekawan');
    }

	public function index()
	{
        $user= $this->db->get_where('user',array('nama_lengkap' => $_SESSION['nama']))->row_array();
        
        $data['persetujuan'] = $this->m_sekawan->get_persetujuan('persetujuan',$user['id_user'])->result_array();
        
		$this->load->view('template/header');
		$this->load->view('template/navbar');
		$this->load->view('user/persetujuan',$data);
		$this->load->view('template/footer');
	}

    public function aksi()
    {
        if(!empty($this->input->post('acc',true))) {
            $this->db->update('persetujuan',array('status' => 1),array('id_persetujuan' => $this->input->post('acc',true)));
            set_log("update","update acc user persetujuan", $this->input->post('acc',true));
        }

        if(!empty($this->input->post('reject',true))) {
            $this->db->update('persetujuan',array('status' => 2),array('id_persetujuan' => $this->input->post('reject',true)));
            set_log("update","update reject user persetujuan", $this->input->post('reject',true));
        }
    }
}
