<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Welcome extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		is_login();
		$this->load->model('m_sekawan');
	}
	public function index()
	{
		$this->load->view('welcome_message');
	}

	public function laporan()
	{

		
		echo "<pre>";
		print_r ($_POST);
		echo "</pre>";
		
		
		$spreadsheet = new Spreadsheet();
		$activeWorksheet = $spreadsheet->getActiveSheet();
		$activeWorksheet->setCellValue('A1', 'Hello World !');
		
		// header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		// header('Content-Disposition: attachment; filename="Laporan Periodik.xlsx"'); // Set nama file excel nya
		// header('Cache-Control: max-age=0');
		// $writer = new Xlsx($spreadsheet);
		// $writer->save('php://output');
	}
}
