<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    public function __construct()
    {
        parent::__construct();

        $this->load->model('m_sekawan');
        // is_login();
    }

	public function index()
	{        
		$this->load->view('template/header');
		$this->load->view('auth/login');
		$this->load->view('template/footer');
	}

    public function login() 
    {
        $username = $this->input->post('username');
		$password = $this->input->post('password');
		$where = array(
			'username' => $username,
			'password' => md5($password)
        );
		$cek = $this->m_sekawan->cek_login("user",$where)->row_array();
		if($cek){
 
			$data_session = array(
				'nama' => $cek['nama_lengkap'],
				'role' => $cek['role']
            );
 
			$this->session->set_userdata($data_session);
            
            if($cek['role'] == 'admin') {
                redirect(base_url("admin"));
                set_log("login_admin","akses login", $username);
            }else{
                redirect(base_url("user"));
                set_log("login_user","akses login", $username);
            }
 
		}else{
			echo "Username dan password salah !";
		}
    }

    public function logout()
    {
        $this->session->sess_destroy();
	    redirect(base_url('auth'));
    }
}
