<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
 
class M_sekawan extends CI_Model{	

	function cek_login($table,$where){		
		return $this->db->get_where($table,$where);
	}
	
	function get_join_order($id){		
		$this->db->join('kendaraan','kendaraan.id_kendaraan = orders.id_kendaraan');
		$this->db->join('persetujuan','persetujuan.id_order = orders.id_order');
		$this->db->join('user','user.id_user = persetujuan.id_user');
		$this->db->where('orders.id_order', $id);
		$this->db->order_by('persetujuan.level', 'asc');
		
		return $this->db->get('orders');
	}	

	function get_persetujuan($table,$id){
		$this->db->join('orders', 'orders.id_order = '.$table.'.id_order');
		$this->db->join('kendaraan', 'kendaraan.id_kendaraan = orders.id_kendaraan');
		$this->db->where('id_user', $id);
		return $this->db->get($table);
		
	}

	function cetak($awal,$akhir) {
		$this->db->join('kendaraan','kendaraan.id_kendaraan = orders.id_kendaraan');
		$this->db->where('orders.tanggal_pesan >=', $awal);
		$this->db->where('orders.tanggal_pesan <=', $akhir);
		
		return $this->db->get('orders');
	}

	function dashboard($table) {
		$this->db->select('*, count('.$table.'.id_kendaraan) as jumlah');
		$this->db->join('kendaraan','kendaraan.id_kendaraan = '.$table.'.id_kendaraan');
		$this->db->group_by($table.'.id_kendaraan');
		$this->db->order_by($table.'.id_kendaraan', 'asc');
		return $this->db->get($table);
	}
}