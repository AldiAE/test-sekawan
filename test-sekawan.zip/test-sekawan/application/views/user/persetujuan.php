<div class="container mt-3">
    <h5>Tabel Persetujuan Pemesanan Kendaraan</h5>
    <br>
    <table id="example" class="display mt-3" style="width:100%">
        <thead>
            <tr>
                <th>No.</th>
                <th>Nama Pemesanan</th>
                <th>Jenis Kendaraan</th>
                <th>Nama Driver</th>
                <th>Tanggal Pesan</th>
                <th>Tanggal Kembali</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach($persetujuan as $key => $o) : 
            ?>
            <tr>
                <td><?=($key+1)?></td>
                <td><?= $o['nama_pemesan']?></td>
                <td><?= $o['nama_kendaraan']?> </td>
                <td><?= $o['nama_driver']?></td>
                <td><?= $o['tanggal_pesan']?></td>
                <td><?= $o['tanggal_kembali']?></td>
                <td>
                    <?php if($o['status'] == 0) : ?>
                        <button type="button" class="btn btn-sm btn-warning btn-rounded" onclick="acc(<?=$o['id_persetujuan']?>)">ACC</button>
                        <button type="button" class="btn btn-sm btn-danger btn-rounded" onclick="reject(<?=$o['id_persetujuan']?>)">REJECT</button>
                    <?php else : ?>
                        <?php if($o['status'] == 1) : ?>
                            <span>ACC</span>
                        <?php else : ?>
                            <span>REJECT</span>
                        <?php endif; ?>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
<link href="https://cdn.datatables.net/v/dt/dt-1.13.4/datatables.min.css" rel="stylesheet"/>
 
<script src="https://cdn.datatables.net/v/dt/dt-1.13.4/datatables.min.js"></script>
<script>
    $(document).ready(function () {
        $('#example').DataTable();
    });

    function acc(id_persetujuan) {
        if(confirm('apakah yakin akan acc data ?')) {
            $.post("<?=base_url('user/aksi')?>", {
                acc : id_persetujuan
            },
                function (data, textStatus, jqXHR) {
                    location.reload()
                },
            );
        }
    }

    function reject(id_persetujuan) {
        if(confirm('apakah yakin akan reject data ?')) {
            $.post("<?=base_url('user/aksi')?>", {
                reject : id_persetujuan
            },
                function (data, textStatus, jqXHR) {
                    location.reload()
                },
            );
        }
    }
</script>