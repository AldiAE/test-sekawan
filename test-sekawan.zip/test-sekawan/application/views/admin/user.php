<!-- Modal Tambah -->
<div class="modal fade" id="tambah" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg ">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Form Tambah</h5>
        <button type="button" class="btn-close" data-mdb-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="<?=base_url('admin/tambah_user')?>" method="post">

            <div class="form-outline mb-2">
                <input type="text" id="nama_lengkap" name="nama_lengkap" class="form-control" />
                <label class="form-label" for="nama_lengkap">Nama User</label>
            </div>
            <div class="form-outline mb-2">
                <input type="text" id="username" name="username" class="form-control" />
                <label class="form-label" for="username">Username</label>
            </div>
            <div class="form-outline mb-2">
                <input type="text" id="password" name="password" class="form-control" />
                <label class="form-label" for="password">Password</label>
            </div>
            <div class="form-outline mb-2">
                <input type="text" id="role" name="role" class="form-control" />
                <label class="form-label" for="role">Role</label>
            </div>
            <div class="mt-3">
                <button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Modal Edit -->
<div class="modal fade" id="edit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg ">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Form Edit</h5>
        <button type="button" class="btn-close" data-mdb-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="form_edit" method="post">

            <div class="form-outline mb-2">
                <input type="text" id="nama_lengkap_edit" name="nama_lengkap" class="form-control" />
                <label class="form-label" for="nama_lengkap">Nama User</label>
            </div>
            <div class="form-outline mb-2">
                <input type="text" id="username_edit" name="username" class="form-control" />
                <label class="form-label" for="username">Username</label>
            </div>
            <div class="form-outline mb-2">
                <input type="text" id="password_edit" name="password" class="form-control" placeholder="Isi kolom ini jika ingin merubah password"/>
                <label class="form-label" for="password">Password</label>
            </div>
            <div class="form-outline mb-2">
                <input type="text" id="role_edit" name="role" class="form-control" />
                <label class="form-label" for="role">Role</label>
            </div>
            <div class="mt-3">
                <button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>

<div class="container mt-3">
    <h5>Data User</h5>
    <div class="float-right mb-3">
        <button type="button" class="btn btn-sm btn-primary btn-rounded" data-mdb-toggle="modal" data-mdb-target="#tambah">Tambah</button>
    </div>
    <table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>No.</th>
                <th>Nama User</th>
                <th>Username</th>
                <th>Role</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($user as $key => $u) : ?>
                <tr>
                    <td><?=$key+1?></td>
                    <td><?=$u['nama_lengkap']?></td>
                    <td><?=$u['username']?></td>
                    <td><?=$u['role']?></td>
                    <td><button type="button" class="btn btn-sm btn-warning btn-rounded" onclick="edit(<?=$u['id_user']?>)">Edit</button></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
<link href="https://cdn.datatables.net/v/dt/dt-1.13.4/datatables.min.css" rel="stylesheet"/>
 
<script src="https://cdn.datatables.net/v/dt/dt-1.13.4/datatables.min.js"></script>
<script>
    $(document).ready(function () {
        $('#example').DataTable();
    });

    function edit(id_user) {
        $.post("<?=base_url('admin/get_user_by_id')?>", {
            id_user : id_user
        },
            function (data, textStatus, jqXHR) {
                let list = JSON.parse(data);
                $('#nama_lengkap_edit').val(list.nama_lengkap);
                $('#username_edit').val(list.username);
                $('#password_edit').val('');
                $('#role_edit').val(list.role);
                $('#form_edit').attr('action','<?=base_url('admin/tambah_user/')?>'+id_user)
                $('#edit').modal('show');

            },
        );
    }
</script>