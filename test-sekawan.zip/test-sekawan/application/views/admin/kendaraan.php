<!-- Modal Tambah -->
<div class="modal fade" id="tambah" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg ">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Form Tambah</h5>
        <button type="button" class="btn-close" data-mdb-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="<?=base_url('admin/tambah_kendaraan')?>" method="post">

            <div class="form-outline mb-2">
                <input type="text" id="nama_kendaraan" name="nama_kendaraan" class="form-control" />
                <label class="form-label" for="nama_kendaraan">Nama Kendaraan</label>
            </div>
            <div class="form-outline mb-2">
                <input type="text" id="konsumsi_bbm" name="konsumsi_bbm" class="form-control" />
                <label class="form-label" for="konsumsi_bbm">Konsumsi BBM</label>
            </div>
            <div class="form-outline mb-2">
                <input type="date" id="jadwal_service" name="jadwal_service" class="form-control" />
                <label class="form-label" for="jadwal_service">Jadwal Service</label>
            </div>
            <div class="mt-3">
                <button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Modal Edit -->
<div class="modal fade" id="edit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg ">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Form Edit</h5>
        <button type="button" class="btn-close" data-mdb-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="form_edit" method="post">

            <div class="form-outline mb-2">
                <input type="text" id="nama_kendaraan_edit" name="nama_kendaraan" class="form-control" />
                <label class="form-label" for="nama_kendaraan">Nama Kendaraan</label>
            </div>
            <div class="form-outline mb-2">
                <input type="text" id="konsumsi_bbm_edit" name="konsumsi_bbm" class="form-control" />
                <label class="form-label" for="konsumsi_bbm">Konsumsi BBM</label>
            </div>
            <div class="form-outline mb-2">
                <input type="date" id="jadwal_service_edit" name="jadwal_service" class="form-control" />
                <label class="form-label" for="jadwal_service">Jadwal Service</label>
            </div>
            <div class="mt-3">
                <button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>

<div class="container mt-3">
    <h5>Data Kendaraan</h5>
    <div class="float-right mb-3">
        <button type="button" class="btn btn-sm btn-primary btn-rounded" data-mdb-toggle="modal" data-mdb-target="#tambah">Tambah</button>
    </div>
    <table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>No.</th>
                <th>Nama Kendaraan</th>
                <th>Konsumsi BBM</th>
                <th>Jadwal Service</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($kendaraan as $key => $kend) : ?>
                <tr>
                    <td><?=$key+1?></td>
                    <td><?=$kend['nama_kendaraan']?></td>
                    <td><?=$kend['konsumsi_bbm']?></td>
                    <td><?=$kend['jadwal_service']?></td>
                    <td>
                    <button type="button" class="btn btn-sm btn-warning btn-rounded" onclick="edit(<?=$kend['id_kendaraan']?>)">Edit</button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
<link href="https://cdn.datatables.net/v/dt/dt-1.13.4/datatables.min.css" rel="stylesheet"/>
 
<script src="https://cdn.datatables.net/v/dt/dt-1.13.4/datatables.min.js"></script>
<script>
    $(document).ready(function () {
        $('#example').DataTable();
    });

    function edit(id_kend) {
        $.post("<?=base_url('admin/get_kendaraan_by_id')?>", {
            id_kend : id_kend
        },
            function (data, textStatus, jqXHR) {
                let list = JSON.parse(data);
                $('#nama_kendaraan_edit').val(list.nama_kendaraan);
                $('#konsumsi_bbm_edit').val(list.konsumsi_bbm);
                $('#jadwal_service_edit').val(list.jadwal_service);
                $('#form_edit').attr('action','<?=base_url('admin/tambah_kendaraan/')?>'+id_kend)
                $('#edit').modal('show');

            },
        );
    }
</script>