<!-- Modal Tambah -->
<div class="modal fade" id="tambah" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg ">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Form Tambah</h5>
        <button type="button" class="btn-close" data-mdb-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="<?=base_url('admin/tambah')?>" method="post">

            <div class="form-outline mb-2">
                <input type="text" id="nama_pemesan" name="nama_pemesan" class="form-control" />
                <label class="form-label" for="nama_pemesan">Nama Pemesan</label>
            </div>
            <div class="form-outline mb-2">
                <input type="text" id="nama_driver" name="nama_driver" class="form-control" />
                <label class="form-label" for="nama_driver">Nama Driver</label>
            </div>
            <div class="form-outline mb-2">
                <input type="date" id="tanggal_pesan" name="tanggal_pesan" class="form-control" />
                <label class="form-label" for="tanggal_pesan">Tanggal Pesan</label>
            </div>
            <div class="form-outline mb-2">
                <input type="date" id="tanggal_kembali" name="tanggal_kembali" class="form-control" />
                <label class="form-label" for="tanggal_kembali">Tanggal Kembali</label>
            </div>
            <select class="form-select mb-2" aria-label="Default select example" id="id_kendaraan" name="nama_kendaraan">
                <option value="" selected>Jenis Kendaraan</option>
                <?php foreach($kendaraan as $kend) : ?>
                    <option value="<?=$kend['id_kendaraan']?>"><?=$kend['nama_kendaraan']?></option>
                <?php endforeach; ?>
            </select>
            <div class="mt-3">
                <button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Modal Edit -->
<div class="modal fade" id="edit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg ">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Form Edit</h5>
        <button type="button" class="btn-close" data-mdb-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="form_edit" method="post">

            <div class="form-outline mb-2">
                <input type="text" id="nama_pemesan_edit" name="nama_pemesan" class="form-control" />
                <label class="form-label" for="nama_pemesan">Nama Pemesan</label>
            </div>
            <div class="form-outline mb-2">
                <input type="text" id="nama_driver_edit" name="nama_driver" class="form-control" />
                <label class="form-label" for="nama_driver">Nama Driver</label>
            </div>
            <div class="form-outline mb-2">
                <input type="date" id="tanggal_pesan_edit" name="tanggal_pesan" class="form-control" />
                <label class="form-label" for="tanggal_pesan">Tanggal Pesan</label>
            </div>
            <div class="form-outline mb-2">
                <input type="date" id="tanggal_kembali_edit" name="tanggal_kembali" class="form-control" />
                <label class="form-label" for="tanggal_kembali">Tanggal Kembali</label>
            </div>
            <select class="form-select mb-2" aria-label="Default select example" id="nama_kendaraan_edit" name="nama_kendaraan">
                <option value="" selected>Jenis Kendaraan</option>
                <?php foreach($kendaraan as $kend) : ?>
                    <option value="<?=$kend['id_kendaraan']?>"><?=$kend['nama_kendaraan']?></option>
                <?php endforeach; ?>
            </select>
            <div class="mt-3">
                <button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="set_persetujuan" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg ">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Form Persetujuan</h5>
        <button type="button" class="btn-close" data-mdb-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="<?=base_url('admin/set_persetujuan')?>" method="post">
            <input type="hidden" name="id_order" id="id_order">
            <?php foreach($users as $u) : ?>
                <div class="form-check">
                <input class="form-check-input" type="checkbox" value="<?=$u['id_user']?>" id="persetujuan" name="persetujuan[]">
                <label class="form-check-label" for="flexCheckChecked">
                    <?= $u['nama_lengkap'] ;?>
                </label>
                </div>
                <?php endforeach; ?>
            <div class="mt-3">
                <button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="cetak" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg ">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Cetak Laporan Excel</h5>
        <button type="button" class="btn-close" data-mdb-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="<?=base_url('admin/laporan')?>" method="post">
        <div class="col">
            <div class="form-outline mb-2">
                <input type="date" id="tanggal_awal" name="tanggal_awal" class="form-control" />
                <label class="form-label" for="tanggal_awal">Tanggal Awal</label>
            </div>

            <div class="form-outline mb-2">
                <input type="date" id="tanggal_akhir" name="tanggal_akhir" class="form-control" />
                <label class="form-label" for="tanggal_akhir">Tanggal Akhir</label>
            </div>
        </div>
            <div class="mt-3">
                <button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>

<div class="container mt-3">
    <h5>Data Order</h5>
    <div class="float-right mb-3">
        <button type="button" class="btn btn-sm btn-primary btn-rounded" data-mdb-toggle="modal" data-mdb-target="#tambah">Tambah</button>
        <button type="button" class="btn btn-sm btn-success btn-rounded float-right" data-mdb-toggle="modal" data-mdb-target="#cetak">Cetak</button>
    </div>
    <table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>No.</th>
                <th>Nama Pemesan</th>
                <th>Jenis Kendaraan</th>
                <th>Nama Driver</th>
                <th>Tanggal Pesan</th>
                <th>Tanggal Kembali</th>
                <th>Persetujuan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($orders as $key => $o) : 
            ?>
            <tr>
                <td><?=($key+1)?></td>
                <td><?= $o['nama_pemesan']?></td>
                <td><?= cr_kend($o['id_kendaraan'])?> </td>
                <td><?= $o['nama_driver']?></td>
                <td><?= $o['tanggal_pesan']?></td>
                <td><?= $o['tanggal_kembali']?></td>
                <td>
                    <?php if(cr_perstj($o['id_order']) == null) :  ?>
                        <button class="btn btn-secondary brn-sm btn-rounded" type="button" onclick="set_persetujuan(<?=$o['id_order']?>)">Persetujuan</button>
                    <?php else :?>
                    <ol>
                    <?php foreach(cr_perstj($o['id_order']) as $p) :?>
                        <li style="<?=$p['status'] == 1 ?'color:green': ($p['status'] == 2 ? 'color:red' : '')?>"><?= $p['nama_lengkap'] ;?></li>
                    <?php endforeach ;?>
                    </ol>
                    <?php endif; ?>
                </td>
                <td>
                    <button type="button" class="btn btn-sm btn-warning btn-rounded" onclick="edit(<?=$o['id_order']?>)">Edit</button>
                    <button type="button" class="btn btn-sm btn-danger btn-rounded" onclick="hapus(<?=$o['id_order']?>)">Delete</button>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
<link href="https://cdn.datatables.net/v/dt/dt-1.13.4/datatables.min.css" rel="stylesheet"/>
 
<script src="https://cdn.datatables.net/v/dt/dt-1.13.4/datatables.min.js"></script>
<script>
    $(document).ready(function () {
        $('#example').DataTable();
    });

    function set_persetujuan(id_order) {
        $('#id_order').val(id_order);
        $('#set_persetujuan').modal('show');
         
    }

    function edit(id_order) {
        $.post("<?=base_url('admin/get_by_id')?>", {
            id_order : id_order
        },
            function (data, textStatus, jqXHR) {
                let list = JSON.parse(data);
                $('#nama_pemesan_edit').val(list.nama_pemesan);
                $('#nama_driver_edit').val(list.nama_driver);
                $('#tanggal_pesan_edit').val(list.tanggal_pesan);
                $('#tanggal_kembali_edit').val(list.tanggal_kembali);
                $('#nama_kendaraan_edit').val(list.id_kendaraan);
                $('#form_edit').attr('action','<?=base_url('admin/tambah/')?>'+id_order)
                $('#edit').modal('show');

            },
        );
    }

    function hapus(id_order) {
        if(confirm('Yakin akan hapus data ?')) {

            $.post("<?=base_url('admin/hapus_by_id')?>", {
                id_order : id_order
            },
                function (data, textStatus, jqXHR) {
                    location.reload()
    
                },
            );
        }
    }
</script>