<?php


function cr_kend($id_kend)
{
    $CI = get_instance();
    $kend = $CI->db->select('nama_kendaraan')->get_where('kendaraan',array('id_kendaraan' => $id_kend))->row_array();
    return $kend['nama_kendaraan'];  
    
}

function cr_perstj($id_order)
{
    $CI = get_instance();
    $CI->db->join('persetujuan','persetujuan.id_order = orders.id_order');
    $CI->db->join('user','user.id_user = persetujuan.id_user');
    $CI->db->where('orders.id_order', $id_order);
    $CI->db->order_by('persetujuan.level','asc');
    $data = $CI->db->get('orders')->result_array();
    return $data;
    
}