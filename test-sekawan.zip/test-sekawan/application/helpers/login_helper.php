<?php

function is_login()
{
    $CI = get_instance();
    $role = $CI->session->userdata('role');
    $uri = $CI->uri->segment(1);

    if(!$role) {
        redirect('auth');
    }else{
        if($role == 'admin' && $uri != 'admin') {
            redirect('admin');
        }

        if($role == 'user' && $uri != 'user') {
            redirect('user');
        }
    }    
    
}