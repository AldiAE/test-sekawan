<?php

function set_log($tipe, $aksi, $item)
{
    $CI =& get_instance();
 
    
    $log['log_user'] = $CI->session->userdata('nama');
    $log['log_tipe'] = $tipe;
    $log['log_aksi'] = $aksi;
    $log['log_item'] = $item;

    $CI->db->insert('log',$log);
}